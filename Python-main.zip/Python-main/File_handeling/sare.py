file= open("C:/Users/sivan/Desktop/data.txt","w")
file.write("how to sum to  numbers")
file.close()
