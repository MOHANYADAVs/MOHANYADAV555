dic   = {"name":34,"age":12}
li  = dic.items()
print(li[0)
