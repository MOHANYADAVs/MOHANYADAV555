file=open("C:/Users/sivan/Desktop/python_intermediate/marks memo.txt","w")
file.write("how to learn python easily")
file.close()
