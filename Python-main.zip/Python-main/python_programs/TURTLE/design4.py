import turtle
paper=turtle.Screen()
pen=turtle.Turtle()
for i in range(500):
    pen.forward(i)
    pen.right(91)
