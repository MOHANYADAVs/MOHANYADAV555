import turtle
paper=turtle.Screen()
pen=turtle.Turtle()
i =0
while True:
    
        pen.forward(i)
        pen.right(i)
        pen.color("red")
        i+=2
        
"""""pen.right(90)
pen.forward(150)
pen.right(90)
pen.forward(100)
pen.right(90)
pen.forward(150)
pen.right(90)"""""
