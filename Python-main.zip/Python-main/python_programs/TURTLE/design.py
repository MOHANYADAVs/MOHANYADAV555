import turtle
paper=turtle.Screen()
pen = turtle.Turtle()
pen.forward(100)
pen.left(45)
pen.forward(110)
pen.right(90)
pen.backward(160)
pen.forward(190)
