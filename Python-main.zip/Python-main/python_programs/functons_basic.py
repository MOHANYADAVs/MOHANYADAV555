# simple functions
a  = int(input())
b  = int(input())


def addition(x,y):
    #c = x+y
    #print(x+y)
    return x+y

addition(a,b)

