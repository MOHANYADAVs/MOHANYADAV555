data=int(input())
for i in range(1,data+1):
    print(i)
