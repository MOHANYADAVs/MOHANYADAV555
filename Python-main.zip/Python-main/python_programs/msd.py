various_numbers=int(input("enter your favorite cricter number"))

while True:
    if various_numbers%2 == 0:
        print("ms dhoni")
        various_numbers += 1
    else:
        print("invalid number")
        break
