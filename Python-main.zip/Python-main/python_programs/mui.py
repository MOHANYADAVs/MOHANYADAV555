
print("welcome to my project")
print("*******************************************************************")
print("choice 1 -  Addtion", "\n", "choice 2 - Multiplication","\n", "choice 3 -  division", "\n","choice 4 -  Subtraction")

choice  = int(intput("please enter your choice of operation ") choice==1:

num1=int(input("enter the value "))
num2=int(input("enter the value "))


def add(m,s):
    c=m+s
    print(m+s)

def mul(m,s):
    c=m*s
    print(m*s)

def div(m,s):
    c=m%s
    print(m%s)

def sub(x,y):
    d=x-y
    print(d)

if choice==1:
              print(addition )
elif choice==2:
    print(multiplication)
elif choice==3:
    print(division)
else:
    print(subtraction)

