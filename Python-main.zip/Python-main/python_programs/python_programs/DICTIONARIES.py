"""""elements={"hydrogen":1,"helium":2,"water":3}
elements['carbon']=4
print(elements)



student_data={'name':'mohan',
              'age':21,
              'qualificaion':'bsc(mecs)'}
student_data['age']
print(student_data)"""""

              
"""""data="mohanyadav8374@gmail.com  87542102555"
b=data.split("  ")
di={}
di[b[0]]=b[1]
di["mohanyadav8374@gmail.com"]=45879513544114441
print(di)"""""

e_mail = input("enter you valid e_mail i'd")
password =int(input("enter your e_mail assword"))
di={}
di[e_mail]= password
print(di)


 
