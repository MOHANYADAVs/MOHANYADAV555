x=10
y=23
x,y=y,x
print(x)
print(y)
