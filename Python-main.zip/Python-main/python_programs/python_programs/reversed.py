#hello world
data= input().split(" ")
b=(reversed(data))
print(" ".join(b))




