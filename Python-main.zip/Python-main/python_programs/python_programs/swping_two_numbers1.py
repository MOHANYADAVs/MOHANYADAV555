m=20
n=14
tem=m
m=n
n=tem
print(m)
print(n)
