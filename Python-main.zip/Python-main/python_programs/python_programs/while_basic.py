#while

myval  =  int(input("enter the choice"))

while True:
    print("mohan")
    myval += 1
    if myval == 25:
        break
    
