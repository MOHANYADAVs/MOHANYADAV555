data=int(input())
num=int(input())
sum=data+num
print(sum)
